import pandas as pd
from abc import ABC, abstractmethod

accessDictionary = {
        "Employee" : False,
        "make" : False,
        "sale_item" : False,
        "sales" : False,
        "supplier" : False,
        "product_request" : False,
        "bakery" : False,
        "Purchase" : False,
        "sold_to" : False,
        "customer" : False,
        "wants_delivery" : False,
        "delivery" : False,
        "request" : False,
        "customer_requests" : False
    }

class Abstract(ABC):
    def __init__(self):
        self.accessDictionary = accessDictionary
        self.empID = None
        self.cursor = None

    @abstractmethod
    def getAccessDetails(self):
        access=self.accessDictionary
        print("I am here")
        return access

    @abstractmethod
    def getTableDetails(self, tableName):
        try:
            if self.accessDictionary[tableName] == True:
                employeeTable = self.getTable(tableName)
                return employeeTable
            raise Exception("Access Denied")
        except Exception as e:
            print(e)
            return None

    def getTable(self,tableName):
        self.cursor.execute("SELECT * from {}".format(tableName))
        table = self.cursor.fetchall()
        return table

    @abstractmethod
    def isUpdateTable(self, tableName):
        try:
            if self.accessDictionary[tableName] == True:
                return True
            raise Exception("Access Denied")
        except Exception as e:
            print(e)
            return False





