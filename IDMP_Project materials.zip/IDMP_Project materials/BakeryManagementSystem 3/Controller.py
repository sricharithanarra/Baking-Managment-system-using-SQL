from ModelDelegator import ModelDelegator
from View import View
from ModelDelegator import ModelDelegator

VIEW_MENU = [
        "Employee",
        "make",
        "sale_item",
        "sales",
        "supplier",
        "product_request",
        "bakery",
        "Purchase",
        "sold_to",
        "customer",
        "wants_delivery",
        "delivery",
        "request",
        "customer_requests"
]

class ControllerLoop:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.LOGIN_MENU = True
        self.VIEW_TABLE_MENU = False
        self.EDIT_TABLE_MENU = False
        self.FEATURES_MENU = False
        self.ADDITIONAL_FEATURES_MENU = False

    def getUserLoginCredentials(self):
        self.view.printUsernameInput()
        username = str(input())
        self.view.printPasswordInput()
        password = str(input())
        return username, password

    def mainLoop(self):
        while(self.LOGIN_MENU):
            try:
                username, password= self.getUserLoginCredentials()
                print(username,password)
                if self.model.verifyUser(username, password):
                    self.FEATURES_MENU = True
                    self.view.printLoggedInMessage()
                    self.featuresMenuLoop()
                raise Exception("Please Enter valid credentials")
            except Exception as e:
                self.view.printException(e)

    def featuresMenuLoop(self):
        while(self.FEATURES_MENU):
            try:
                self.view.printFeaturesMenu()
                match str(input()):
                    case '1':
                        self.VIEW_TABLE_MENU = True
                        self.viewTableMenuLoop()
                    case '2':
                        self.EDIT_TABLE_MENU = True
                        self.editTableMenuLoop()
                    case '3':
                        self.ADDITIONAL_FEATURES_MENU = True
                        self.additionalFeaturesMenuLoop()
                    case 'back':
                        self.FEATURES_MENU = False
                    case _:
                        raise Exception("Please enter valid input")
            except Exception as e:
                self.view.printException(e)

    def viewTableMenuLoop(self):
        while(self.VIEW_TABLE_MENU):
            try:
                self.view.printViewTableMenu()
                match str(input()):
                    case "1":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[0]))
                    case "2":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[1]))
                    case "3":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[2]))
                    case "4":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[3]))
                    case "5":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[4]))
                    case "6":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[5]))
                    case "7":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[6]))
                    case "8":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[7]))
                    case "9":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[8]))
                    case "10":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[9]))
                    case "11":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[10]))
                    case "12":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[11]))
                    case "13":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[12]))
                    case "14":
                        self.view.printTableDetails(self.model.getTableValue(VIEW_MENU[13]))
                    case 'back':
                        self.VIEW_TABLE_MENU = False
                    case _:
                        raise Exception("Please enter valid input")
            except Exception as e:
                self.view.printException(e)

    def additionalFeaturesMenuLoop(self):
        while(self.ADDITIONAL_FEATURES_MENU):
            try:
                self.view.printAdditionalFeaturesMENU()
                match str(input()):
                    case "1":
                        self.view.printSalesChartByLocation(self.model.querySalesGroupedByLocation())
                    case "2":
                        self.view.printProfitLossStatement(self.model.queryProfitLossStatement())
                    case "3":
                        self.view.printDeliveryScore(self.model.queryDeliveryScore())
                    case 'back':
                        self.ADDITIONAL_FEATURES_MENU = False
                    case _:
                        raise Exception("Please enter valid input")
            except Exception as e:
                self.view.printException(e)

    def editTableMenuLoop(self):
        while(self.EDIT_TABLE_MENU):
            try:
                self.view.printEditTableMenu()
                match str(input()):
                    case "1":
                        print("Enter new customer ID:")
                        val1=str(input())
                        print("Enter name:")
                        val2=str(input())
                        print("Enter phone number:")
                        val3=str(input())
                        print("Enter last name:")
                        val4=str(input())
                        status = self.model.addToCustomerTable(val1, val2, val3, val4)
                        if status:
                            self.view.printSuccessMessage()
                    case "2":
                        print("Enter the delivery ID:")
                        val1=str(input())
                        print("Enter the address:")
                        val2=str(input())
                        print("Enter the postal code:")
                        val3=str(input())
                        print("Enter the delivery score:")
                        val4=str(input())
                        status = self.model.addToDeliveryTable(val1, val2, val3, val4)
                        if status:
                            self.view.printSuccessMessage()
                    case "3":
                        print("Enter the customer request ID:")
                        val1=str(input())
                        print("Enter the customer ID:")
                        val2=str(input())
                        print("Enter the requested product:")
                        val3=str(input())
                        print("Enter the date for request:")
                        val4=str(input())
                        status = self.model.addToCustomerRequestTable(val1, val2, val3, val4)
                        if status:
                            self.view.printSuccessMessage()
                    case "4":
                        print("Enter the name that you want to update:")
                        val1=str(input())
                        print("Enter the corresponding customer ID:")
                        val2=str(input())
                        status = self.model.updateCustomerTable(val1, val2)
                        if status:
                            self.view.printSuccessMessage()
                    case "5":
                        print("Enter the customer request:")
                        val1=str(input())
                        print("Enter the corresponding request ID:")
                        val2=str(input())
                        status = self.model.updateCustomerRequestTable(val1, val2)
                        if status:
                            self.view.printSuccessMessage()
                    case "6":
                        print("Name:")
                        val1=str(input())
                        print("ID:")
                        val2=str(input())
                        status = self.model.updateEmployeeName(val1, val2)
                        if status:
                            self.view.printSuccessMessage()
                    case 'back':
                        self.EDIT_TABLE_MENU = False
                    case _:
                        raise Exception("Please enter valid input")
            except Exception as e:
                self.view.printException(e)



if __name__ == "__main__":
    model = ModelDelegator()
    view = View()
    ControllerLoop(model,view).mainLoop()
    



                    



